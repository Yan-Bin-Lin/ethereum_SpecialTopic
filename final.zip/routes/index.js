const express = require('express');
const router = express.Router();

const Web3 = require('web3');

const web3 = new Web3('http://localhost:8545');

const contract = require('../contract/Bank.json');

/*

/* GET home page. */

/*
router.get('/', async function (req, res, next) {
  res.render('index')
});
*/

//get accounts

router.get('/accounts', async function (req, res, next) {
  let accounts = await web3.eth.getAccounts()
  res.send(accounts)
});


/*
//login
router.get('/balance', async function (req, res, next) {
  let ethBalance = await web3.eth.getBalance(req.query.account)
  res.send({
    ethBalance: ethBalance
  })
});
*/

/*
//balance
router.get('/allBalance', async function (req, res, next) {
  let bank = new web3.eth.Contract(contract.abi);
  bank.options.address = req.query.address;
  let ethBalance = await web3.eth.getBalance(req.query.account)
  let bankBalance = await bank.methods.getBankBalance().call({ from: req.query.account })
    let coinBalance = await bank.methods.getCoinBalance().call({ from: req.query.account })
  res.send({
    ethBalance: ethBalance,
    bankBalance: bankBalance,
      coinBalance: coinBalance
  })
});
*/

/*
//contract
router.get('/contract', function (req, res, next) {
  let bank = new web3.eth.Contract(contract.abi);
  bank.options.address = req.query.address;
  res.send({
    bank: bank
  })
});
*/

/*
//unlock account
router.post('/unlock', function (req, res, next) {
  web3.eth.personal.unlockAccount(req.body.account, req.body.password, 60)
    .then(function (result) {
      res.send('true')
    })
    .catch(function (err) {
      res.send('false')
    })
});
*/


//deploy bank contract
router.post('/deploy', function (req, res, next) {
    let election = new web3.eth.Contract(contract.abi);
  election.deploy({
    data: contract.bytecode
  })
    .send({
      from: req.body.account,
      gas: 3400000
    })
    .on('receipt', function (receipt) {
      res.send(receipt);
    })
    .on('error', function (error) {
      res.send(error.toString());
    })
});

/*
//deposit ether
router.post('/deposit', function (req, res, next) {
  let bank = new web3.eth.Contract(contract.abi);
  bank.options.address = req.body.address;
  bank.methods.deposit().send({
    from: req.body.account,
    gas: 3400000,
    value: web3.utils.toWei(req.body.value, 'ether')
  })
    .on('receipt', function (receipt) {
      res.send(receipt);
    })
    .on('error', function (error) {
      res.send(error.toString());
    })
});

*/

/*
//withdraw ether
router.post('/withdraw', function (req, res, next) {
  let bank = new web3.eth.Contract(contract.abi);
  bank.options.address = req.body.address;
  bank.methods.withdraw(req.body.value).send({
    from: req.body.account,
    gas: 3400000
  })
    .on('receipt', function (receipt) {
      res.send(receipt);
    })
    .on('error', function (error) {
      res.send(error.toString());
    })
});

*/

/*
//transfer ether
router.post('/transfer', function (req, res, next) {
  let bank = new web3.eth.Contract(contract.abi);
  bank.options.address = req.body.address;
  bank.methods.transfer(req.body.to, req.body.value).send({
    from: req.body.account,
    gas: 3400000
  })
    .on('receipt', function (receipt) {
      res.send(receipt);
    })
    .on('error', function (error) {
      res.send(error.toString());
    })
});
*/

/*
//kill contract
router.post('/kill', function (req, res, next) {
  let bank = new web3.eth.Contract(contract.abi);
  bank.options.address = req.body.address;
  bank.methods.kill().send({
    from: req.body.account,
    gas: 3400000
  })
    .on('receipt', function (receipt) {
      res.send(receipt);
    })
    .on('error', function (error) {
      res.send(error.toString());
    })
});
*/

let candidate = {
    num : 0,
    name : [],
    id : [],
}

let number_value = [2, 3, 5, 7, 11];
let number_count = 0;

let key ={
    "p": "139",
    "g": "3",
    "h": "44",
    "x": "12"
};

router.post('/Addkey', async function (req, res, next) {
    // TODO

    //add pasword, 作為身份辨識, 只有知道密碼的人能投票
    let sha3 = web3.utils.soliditySha3(req.body.Key)

    let election = new web3.eth.Contract(contract.abi);
    election.options.address = req.body.address;
    election.methods.AddKeys(sha3).send({
        from: req.body.account,
        gas: 3400000
    })
        .on('receipt', function (receipt) {
            res.send(receipt);
        })
        .on('error', function (error) {
            res.send(error.toString());
        })
});


router.post('/Candidate', async function (req, res, next) {
  // TODO

    let election = new web3.eth.Contract(contract.abi);
    election.options.address = req.body.address;
    election.methods.createCandidate(req.body.Candidate_Name).send({
        from: req.body.account,
        gas: 3400000
    })
        .on('receipt', function (receipt) {

            number_count += 1;
            console.log(number_count)
            candidate.num += 1;
            console.log(candidate.num)
            console.log("name = ")
            candidate.name.push(req.body.Candidate_Name);
            console.log(req.body.name)
            candidate.id.push(number_value[number_count - 1]);
            console.log(number_value[number_count - 1])

            res.send({
                receipt : receipt,
                candidate : candidate
            });

        })
        .on('error', function (error) {
            res.send(error.toString());
        })
});

//Vote
router.post('/Vote', function (req, res, next) {
  // TODO

    let y = Math.floor(Math.random() * (key.p / 2 - 3)) + 2;
    //y = 52;
    console.log("y = " + y.toString())

    function pow(base, power, mod){
        let n = 1;
        for(let i = 0;i < power;i ++){
            n = n * base % mod;
        }
        return n;
    }

    let C1 = pow(key.g, y, key.p);
    console.log("c1 = " + C1.toString())

    let s = pow(key.h, y, key.p);
    console.log("s = " + s.toString())
    let C2 = (req.body.Choose_Number * s) % key.p;
    console.log("c2 = " + C2.toString())

    let election = new web3.eth.Contract(contract.abi);
    election.options.address = req.body.address;
    election.methods.keyAndVote(req.body.password, C1, C2, key.p).send({
        from: req.body.account,
        gas: 3400000
    })
        .on('receipt', function (receipt) {
            res.send({
                receipt : receipt,
                C1 : C1,
                C2 : C2
            });
        })
        .on('error', function (error) {
            res.send(error.toString());
        })
});

//open
router.post('/Open', function (req, res, next) {
  // TODO
    console.log('here is open')
    let election = new web3.eth.Contract(contract.abi);
    election.options.address = req.body.address;
    election.methods.decode(key.p, key.x).call({
        from: req.body.account,
        gas: 3400000
    })
        .then(function (receipt) {

            console.log('open success')
            console.log(receipt)

            //initialize
            let count = []
            for(let i = 0; i < candidate.num;i ++){
                count.push(0)
            }
            //將得到的結果因數分解
            while(receipt > 1){
                for(let i = 0;i < candidate.num; i ++){
                    if(receipt % candidate.id[i] == 0){
                        count[i] ++;
                        receipt /= candidate.id[i]
                    }
                }
            }

            candidate.count = count

        res.send(candidate);
    })

});

/*

//transfer Coin
router.post('/transferCoin', function (req, res, next) {
  // TODO
    let bank = new web3.eth.Contract(contract.abi);
    bank.options.address = req.body.address;
    bank.methods.transferCoin(req.body.to, req.body.value).send({
        from: req.body.account,
        gas: 3400000
    }).on('receipt', function (receipt) {
        console.log('success')
        console.log(receipt)
        res.send(receipt);
    }).on('error', function (error) {
        console.log('error')
        console.log(error.toString())
        res.send(error.toString());
    })
});

//transfer Owner
router.post('/transferOwner', function (req, res, next) {
  // TODO
    let bank = new web3.eth.Contract(contract.abi);
    bank.options.address = req.body.address;
    bank.methods.transferOwner(req.body.to).send({
        from: req.body.account,
        gas: 3400000
    }).on('receipt', function (receipt) {
        console.log('success')
        console.log(receipt)
        res.send(receipt);
    }).on('error', function (error) {
        console.log('error')
        console.log(error.toString())
        res.send(error.toString());
    })
});

//transfer ether to other address
router.post('/transferTo', async function (req, res, next) {
  // TODO
    let bank = new web3.eth.Contract(contract.abi);
    let gasfee = 0;
    bank.options.address = req.body.address;
    bank.methods.transfer(req.body.to, req.body.value).estimateGas({
        from: req.body.account,
        gas: 3400000
    }).then(function(gas){
        gasfee = gas;
        console.log('estimate gas = ' + gas.toString())
    })

    bank.methods.transfer(req.body.to, req.body.value - gasfee).send({
        from: req.body.account,
        gas: 3400000
    })
        .on('receipt', function (receipt) {
            res.send(receipt);
        })
        .on('error', function (error) {
            res.send(error.toString());
        })
});

*/
module.exports = router;
